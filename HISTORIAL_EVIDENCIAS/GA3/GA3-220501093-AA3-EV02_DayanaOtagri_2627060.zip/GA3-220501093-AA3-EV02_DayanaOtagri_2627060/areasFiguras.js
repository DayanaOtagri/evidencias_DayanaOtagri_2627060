function calcularAreaCuadrado(lado) {
  const area = lado * lado;
  return area;
}

const ladoCuadrado = 15;
const areaCuadrado = calcularAreaCuadrado(ladoCuadrado);
console.log("Área cuadrado:", areaCuadrado);


function calcularAreaRectangulo(base, altura) {
  const area = base * altura;
  return area;
}


const baseRectangulo = 18;
const alturaRectangulo = 25;

const areaRectangulo = calcularAreaRectangulo(baseRectangulo, alturaRectangulo);

console.log("Área del rectángulo:", areaRectangulo);